import React from 'react';

const SubHeading = () => (
  <div>
    SubHeading
  </div>
);

export default SubHeading;
